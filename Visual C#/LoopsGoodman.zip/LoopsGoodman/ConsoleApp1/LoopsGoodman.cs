﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
 class LoopsGoodman
        {
            public static void Main()
            {




                //~~~WHILE LOOP~~~

                const int SIZE = 6;
                int test = 1;
                int[] score = new int[SIZE];
                int scores;

                while(test <= 5 )	
                {

                Console.WriteLine("Score for test " + test + ":");

                    if (int.TryParse(Console.ReadLine(),out scores))
                    {


                        score[test] = scores;

                    }
                    else
                    {
                    Console.WriteLine("Error: Only use whole numbers");
                    }


                test++;


                }

                double combined = score[1] + score[2] + score[3] + score[4] + score[5];
                Console.WriteLine("Test Average = " + combined / 5);

                /*

                //~~~DO WHILE LOOP~~~

                const int SIZE = 6;
                int test = 1;
                int[] score = new int[SIZE];
                int scores;

                do
                {
                Console.WriteLine("Score for test " + test + ":");

                    if (int.TryParse(Console.ReadLine(),out scores))
                    {


                        score[test] = scores;

                    }
                    else
                    {
                    Console.WriteLine("Error: Only use whole numbers");
                    }


                test++;


                }
                while(test <= 5);

                double combined = score[1] + score[2] + score[3] + score[4] + score[5];
                Console.WriteLine("Test Average = " + combined / 5);
                */

                /*
                const int SIZE = 6;
                int[] score = new int[SIZE];
                int scores;

                for(int test = 1; test <= 5; test++)
                {
                Console.WriteLine("Score for test " + test + ":");

                    if (int.TryParse(Console.ReadLine(),out scores))
                    {


                        score[test] = scores;

                    }
                    else
                    {
                    Console.WriteLine("Error: Only use whole numbers");
                    }
                }

                double combined = score[1] + score[2] + score[3] + score[4] + score[5];
                Console.WriteLine("Test Average = " + combined / 5);
                */
            }
        }
    }


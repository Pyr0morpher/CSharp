﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace StudentStructureGoodman
{
    struct StudentEntry
    {
        public string name;
        public int id;
        public string major;
    }
    public partial class StudentStructureGoodman : Form
    {
        private List<StudentEntry> students =
            new List<StudentEntry>();

        public StudentStructureGoodman()
        {
            InitializeComponent();
        }
        //GetData is used to pass data from one method to another
        private void GetData(ref StudentEntry students)
        {
            try
            {
                students.id = int.Parse(txtStudentID.Text);
                students.name = txtName.Text;
                students.major = txtMajor.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //output the students
        private void DisplayNames()
        {
            string output;

            StudentEntries.Items.Clear();
            foreach (StudentEntry aEntry in students)
            {
                output = aEntry.name + " " + aEntry.major + " " + aEntry.id;

                StudentEntries.Items.Add(output);

            }
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            

            

        }
        //exit button 
        private void button2_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void StudentEntrys_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = StudentEntries.SelectedIndex;
           
        }
        //method to save students
        private void WriteStudent()
        {
            StudentEntry entry = new StudentEntry();

            GetData(ref entry);

            students.Add(entry);         txtMajor.Clear();
            txtName.Clear();
            txtStudentID.Clear();

            txtName.Focus();

        }

       
        private void btnWriteStudent_Click(object sender, EventArgs e)
        {
            WriteStudent();
            DisplayNames();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DisplayNames();
        }
    }
}

﻿namespace TaxTipTotalGoodman
{
    partial class TaxTipTotalGoodman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TaxTipTotalGoodman));
            this.enterMealLabel = new System.Windows.Forms.Label();
            this.mealLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.tipLabel = new System.Windows.Forms.Label();
            this.costLabel = new System.Windows.Forms.Label();
            this.outputMeal = new System.Windows.Forms.Label();
            this.outputTax = new System.Windows.Forms.Label();
            this.outputTip = new System.Windows.Forms.Label();
            this.outputTotal = new System.Windows.Forms.Label();
            this.inputMealCost = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // enterMealLabel
            // 
            this.enterMealLabel.AutoSize = true;
            this.enterMealLabel.Location = new System.Drawing.Point(12, 11);
            this.enterMealLabel.Name = "enterMealLabel";
            this.enterMealLabel.Size = new System.Drawing.Size(106, 13);
            this.enterMealLabel.TabIndex = 0;
            this.enterMealLabel.Text = "Enter the Meal Cost: ";
            // 
            // mealLabel
            // 
            this.mealLabel.AutoSize = true;
            this.mealLabel.Location = new System.Drawing.Point(12, 89);
            this.mealLabel.Name = "mealLabel";
            this.mealLabel.Size = new System.Drawing.Size(69, 13);
            this.mealLabel.TabIndex = 1;
            this.mealLabel.Text = "Cost of Meal:";
            // 
            // taxLabel
            // 
            this.taxLabel.AutoSize = true;
            this.taxLabel.Location = new System.Drawing.Point(12, 120);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(64, 13);
            this.taxLabel.TabIndex = 2;
            this.taxLabel.Text = "Cost of Tax:";
            // 
            // tipLabel
            // 
            this.tipLabel.AutoSize = true;
            this.tipLabel.Location = new System.Drawing.Point(12, 154);
            this.tipLabel.Name = "tipLabel";
            this.tipLabel.Size = new System.Drawing.Size(61, 13);
            this.tipLabel.TabIndex = 3;
            this.tipLabel.Text = "Cost of Tip:";
            // 
            // costLabel
            // 
            this.costLabel.AutoSize = true;
            this.costLabel.Location = new System.Drawing.Point(12, 184);
            this.costLabel.Name = "costLabel";
            this.costLabel.Size = new System.Drawing.Size(61, 13);
            this.costLabel.TabIndex = 4;
            this.costLabel.Text = "Total Cost: ";
            // 
            // outputMeal
            // 
            this.outputMeal.AutoSize = true;
            this.outputMeal.Location = new System.Drawing.Point(88, 89);
            this.outputMeal.Name = "outputMeal";
            this.outputMeal.Size = new System.Drawing.Size(10, 13);
            this.outputMeal.TabIndex = 5;
            this.outputMeal.Text = ".";
            // 
            // outputTax
            // 
            this.outputTax.AutoSize = true;
            this.outputTax.Location = new System.Drawing.Point(88, 120);
            this.outputTax.Name = "outputTax";
            this.outputTax.Size = new System.Drawing.Size(10, 13);
            this.outputTax.TabIndex = 6;
            this.outputTax.Text = ".";
            // 
            // outputTip
            // 
            this.outputTip.AutoSize = true;
            this.outputTip.Location = new System.Drawing.Point(88, 154);
            this.outputTip.Name = "outputTip";
            this.outputTip.Size = new System.Drawing.Size(10, 13);
            this.outputTip.TabIndex = 7;
            this.outputTip.Text = ".";
            // 
            // outputTotal
            // 
            this.outputTotal.AutoSize = true;
            this.outputTotal.Location = new System.Drawing.Point(88, 184);
            this.outputTotal.Name = "outputTotal";
            this.outputTotal.Size = new System.Drawing.Size(10, 13);
            this.outputTotal.TabIndex = 8;
            this.outputTotal.Text = ".";
            // 
            // inputMealCost
            // 
            this.inputMealCost.Location = new System.Drawing.Point(125, 11);
            this.inputMealCost.Name = "inputMealCost";
            this.inputMealCost.Size = new System.Drawing.Size(100, 20);
            this.inputMealCost.TabIndex = 9;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(15, 227);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(103, 23);
            this.calculateButton.TabIndex = 10;
            this.calculateButton.Text = "&Calculate Total";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(156, 227);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(103, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // TaxTipTotalGoodman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(271, 262);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.inputMealCost);
            this.Controls.Add(this.outputTotal);
            this.Controls.Add(this.outputTip);
            this.Controls.Add(this.outputTax);
            this.Controls.Add(this.outputMeal);
            this.Controls.Add(this.costLabel);
            this.Controls.Add(this.tipLabel);
            this.Controls.Add(this.taxLabel);
            this.Controls.Add(this.mealLabel);
            this.Controls.Add(this.enterMealLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TaxTipTotalGoodman";
            this.Text = "Tax Tip and Total";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label enterMealLabel;
        private System.Windows.Forms.Label mealLabel;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Label tipLabel;
        private System.Windows.Forms.Label costLabel;
        private System.Windows.Forms.Label outputMeal;
        private System.Windows.Forms.Label outputTax;
        private System.Windows.Forms.Label outputTip;
        private System.Windows.Forms.Label outputTotal;
        private System.Windows.Forms.TextBox inputMealCost;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}


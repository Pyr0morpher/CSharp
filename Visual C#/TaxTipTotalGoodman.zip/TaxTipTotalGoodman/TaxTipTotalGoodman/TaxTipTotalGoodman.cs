﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaxTipTotalGoodman
{
    public partial class TaxTipTotalGoodman : Form
    {
        public TaxTipTotalGoodman()
        {
            InitializeComponent();
        }

        const double TAX = .07;
        const double TIP = .15;

        private void calculateButton_Click(object sender, EventArgs e)
        {

            double mealCost; //cost of the meal


            if (double.TryParse(inputMealCost.Text, out mealCost)) {

                double tipCost = mealCost * TIP;
                double taxCost = mealCost * TAX;
                double totalCost = mealCost + tipCost + taxCost;

                outputMeal.Text = "$ " + mealCost.ToString();
                outputTax.Text = "$ " + taxCost.ToString();
                outputTip.Text = "$ " + tipCost.ToString();
                outputTotal.Text = "$ " + totalCost.ToString(); ;
            }
            else {
                outputMeal.Text = "ERROR! (enter a decimal number)";
                outputTax.Text = "ERROR!";
                outputTip.Text = "ERROR!";
                outputTotal.Text = "ERROR!";
            }




        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

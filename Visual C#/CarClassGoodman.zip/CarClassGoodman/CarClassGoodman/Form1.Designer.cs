﻿namespace CarClassGoodman
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.createObjectButton = new System.Windows.Forms.Button();
            this.objectPropertiesGroupBox = new System.Windows.Forms.GroupBox();
            this.speedLabel = new System.Windows.Forms.Label();
            this.makeLabel = new System.Windows.Forms.Label();
            this.yearLabel = new System.Windows.Forms.Label();
            this.outputSpeedLabel = new System.Windows.Forms.Label();
            this.outputMakeLabel = new System.Windows.Forms.Label();
            this.outputYearLabel = new System.Windows.Forms.Label();
            this.enterDataGroupBox = new System.Windows.Forms.GroupBox();
            this.speedTextBox = new System.Windows.Forms.TextBox();
            this.makeTextBox = new System.Windows.Forms.TextBox();
            this.yearTextBox = new System.Windows.Forms.TextBox();
            this.promptSpeedLabel = new System.Windows.Forms.Label();
            this.promptMakeLabel = new System.Windows.Forms.Label();
            this.promptYearLabel = new System.Windows.Forms.Label();
            this.objectPropertiesGroupBox.SuspendLayout();
            this.enterDataGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(108, 254);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 41);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // createObjectButton
            // 
            this.createObjectButton.Location = new System.Drawing.Point(27, 254);
            this.createObjectButton.Name = "createObjectButton";
            this.createObjectButton.Size = new System.Drawing.Size(75, 41);
            this.createObjectButton.TabIndex = 6;
            this.createObjectButton.Text = "&Create Object";
            this.createObjectButton.UseVisualStyleBackColor = true;
            this.createObjectButton.Click += new System.EventHandler(this.createObjectButton_Click);
            // 
            // objectPropertiesGroupBox
            // 
            this.objectPropertiesGroupBox.Controls.Add(this.speedLabel);
            this.objectPropertiesGroupBox.Controls.Add(this.makeLabel);
            this.objectPropertiesGroupBox.Controls.Add(this.yearLabel);
            this.objectPropertiesGroupBox.Controls.Add(this.outputSpeedLabel);
            this.objectPropertiesGroupBox.Controls.Add(this.outputMakeLabel);
            this.objectPropertiesGroupBox.Controls.Add(this.outputYearLabel);
            this.objectPropertiesGroupBox.Location = new System.Drawing.Point(12, 118);
            this.objectPropertiesGroupBox.Name = "objectPropertiesGroupBox";
            this.objectPropertiesGroupBox.Size = new System.Drawing.Size(186, 124);
            this.objectPropertiesGroupBox.TabIndex = 5;
            this.objectPropertiesGroupBox.TabStop = false;
            this.objectPropertiesGroupBox.Text = "Object Properties";
            // 
            // speedLabel
            // 
            this.speedLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.speedLabel.Location = new System.Drawing.Point(59, 85);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(100, 23);
            this.speedLabel.TabIndex = 7;
            this.speedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // makeLabel
            // 
            this.makeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.makeLabel.Location = new System.Drawing.Point(59, 55);
            this.makeLabel.Name = "makeLabel";
            this.makeLabel.Size = new System.Drawing.Size(100, 23);
            this.makeLabel.TabIndex = 6;
            this.makeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // yearLabel
            // 
            this.yearLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yearLabel.Location = new System.Drawing.Point(59, 25);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(100, 23);
            this.yearLabel.TabIndex = 4;
            this.yearLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputSpeedLabel
            // 
            this.outputSpeedLabel.AutoSize = true;
            this.outputSpeedLabel.Location = new System.Drawing.Point(12, 90);
            this.outputSpeedLabel.Name = "outputSpeedLabel";
            this.outputSpeedLabel.Size = new System.Drawing.Size(41, 13);
            this.outputSpeedLabel.TabIndex = 5;
            this.outputSpeedLabel.Text = "Speed:";
            // 
            // outputMakeLabel
            // 
            this.outputMakeLabel.AutoSize = true;
            this.outputMakeLabel.Location = new System.Drawing.Point(17, 60);
            this.outputMakeLabel.Name = "outputMakeLabel";
            this.outputMakeLabel.Size = new System.Drawing.Size(37, 13);
            this.outputMakeLabel.TabIndex = 4;
            this.outputMakeLabel.Text = "Make:";
            // 
            // outputYearLabel
            // 
            this.outputYearLabel.AutoSize = true;
            this.outputYearLabel.Location = new System.Drawing.Point(18, 29);
            this.outputYearLabel.Name = "outputYearLabel";
            this.outputYearLabel.Size = new System.Drawing.Size(32, 13);
            this.outputYearLabel.TabIndex = 3;
            this.outputYearLabel.Text = "Year:";
            // 
            // enterDataGroupBox
            // 
            this.enterDataGroupBox.Controls.Add(this.speedTextBox);
            this.enterDataGroupBox.Controls.Add(this.makeTextBox);
            this.enterDataGroupBox.Controls.Add(this.yearTextBox);
            this.enterDataGroupBox.Controls.Add(this.promptSpeedLabel);
            this.enterDataGroupBox.Controls.Add(this.promptMakeLabel);
            this.enterDataGroupBox.Controls.Add(this.promptYearLabel);
            this.enterDataGroupBox.Location = new System.Drawing.Point(12, 12);
            this.enterDataGroupBox.Name = "enterDataGroupBox";
            this.enterDataGroupBox.Size = new System.Drawing.Size(186, 100);
            this.enterDataGroupBox.TabIndex = 4;
            this.enterDataGroupBox.TabStop = false;
            this.enterDataGroupBox.Text = "Enter Car Data";
            // 
            // speedTextBox
            // 
            this.speedTextBox.Location = new System.Drawing.Point(62, 74);
            this.speedTextBox.Name = "speedTextBox";
            this.speedTextBox.Size = new System.Drawing.Size(100, 20);
            this.speedTextBox.TabIndex = 5;
            // 
            // makeTextBox
            // 
            this.makeTextBox.Location = new System.Drawing.Point(62, 48);
            this.makeTextBox.Name = "makeTextBox";
            this.makeTextBox.Size = new System.Drawing.Size(100, 20);
            this.makeTextBox.TabIndex = 4;
            // 
            // yearTextBox
            // 
            this.yearTextBox.Location = new System.Drawing.Point(62, 22);
            this.yearTextBox.Name = "yearTextBox";
            this.yearTextBox.Size = new System.Drawing.Size(100, 20);
            this.yearTextBox.TabIndex = 3;
            // 
            // promptSpeedLabel
            // 
            this.promptSpeedLabel.AutoSize = true;
            this.promptSpeedLabel.Location = new System.Drawing.Point(13, 77);
            this.promptSpeedLabel.Name = "promptSpeedLabel";
            this.promptSpeedLabel.Size = new System.Drawing.Size(41, 13);
            this.promptSpeedLabel.TabIndex = 2;
            this.promptSpeedLabel.Text = "Speed:";
            // 
            // promptMakeLabel
            // 
            this.promptMakeLabel.AutoSize = true;
            this.promptMakeLabel.Location = new System.Drawing.Point(17, 52);
            this.promptMakeLabel.Name = "promptMakeLabel";
            this.promptMakeLabel.Size = new System.Drawing.Size(37, 13);
            this.promptMakeLabel.TabIndex = 1;
            this.promptMakeLabel.Text = "Make:";
            // 
            // promptYearLabel
            // 
            this.promptYearLabel.AutoSize = true;
            this.promptYearLabel.Location = new System.Drawing.Point(18, 25);
            this.promptYearLabel.Name = "promptYearLabel";
            this.promptYearLabel.Size = new System.Drawing.Size(32, 13);
            this.promptYearLabel.TabIndex = 0;
            this.promptYearLabel.Text = "Year:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(209, 301);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.createObjectButton);
            this.Controls.Add(this.objectPropertiesGroupBox);
            this.Controls.Add(this.enterDataGroupBox);
            this.Name = "Form1";
            this.Text = "Car Class";
            this.objectPropertiesGroupBox.ResumeLayout(false);
            this.objectPropertiesGroupBox.PerformLayout();
            this.enterDataGroupBox.ResumeLayout(false);
            this.enterDataGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button createObjectButton;
        private System.Windows.Forms.GroupBox objectPropertiesGroupBox;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.Label makeLabel;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.Label outputSpeedLabel;
        private System.Windows.Forms.Label outputMakeLabel;
        private System.Windows.Forms.Label outputYearLabel;
        private System.Windows.Forms.GroupBox enterDataGroupBox;
        private System.Windows.Forms.TextBox speedTextBox;
        private System.Windows.Forms.TextBox makeTextBox;
        private System.Windows.Forms.TextBox yearTextBox;
        private System.Windows.Forms.Label promptSpeedLabel;
        private System.Windows.Forms.Label promptMakeLabel;
        private System.Windows.Forms.Label promptYearLabel;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarClassGoodman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void getCarData(Car car)
        {
            double speed;

            yearTextBox.Text = car.Year.ToString();

            car.Make = makeTextBox.Text;

            if (double.TryParse(speedTextBox.Text, out speed))
            {
                speedTextBox.Text = car.Speed.ToString();
            }
            else
            {
                MessageBox.Show("ERROR: Invalid Speed");
            }
        }

        private void createObjectButton_Click(object sender, EventArgs e)
        {
            Car myCar = new Car();

            getCarData(myCar);

            yearLabel.Text = myCar.Year.ToString();
            makeLabel.Text = myCar.Make.ToString();
            speedLabel.Text = myCar.Speed.ToString();


            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

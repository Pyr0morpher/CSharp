﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Friend_File
{
    public partial class FileInputOutputGoodman : Form
    {
        public FileInputOutputGoodman()
        {
            InitializeComponent();
        }

        private void writeNameButton_Click(object sender, EventArgs e)
        {
            try
            {

                StreamWriter outputFile;

                outputFile = File.CreateText("Friends.txt");

                outputFile.WriteLine(nameTextBox.Text);

                outputFile.Close();

                string friendName;

                StreamReader inputFile;

                inputFile = File.OpenText("Friends.txt");

                while (!inputFile.EndOfStream)
                {

                    friendName = inputFile.ReadLine();

                    NamesListBox.Items.Add(friendName);

                }

                inputFile.Close();


            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            NamesListBox.Items.Clear();
            this.Close();
        }
    }
}

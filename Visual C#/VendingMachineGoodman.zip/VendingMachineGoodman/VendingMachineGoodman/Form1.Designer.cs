﻿namespace VendingMachineGoodman
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bepisName = new System.Windows.Forms.Label();
            this.cBepisName = new System.Windows.Forms.Label();
            this.conkName = new System.Windows.Forms.Label();
            this.pepperName = new System.Windows.Forms.Label();
            this.waterName = new System.Windows.Forms.Label();
            this.salesLabel = new System.Windows.Forms.Label();
            this.water = new System.Windows.Forms.PictureBox();
            this.pepper = new System.Windows.Forms.PictureBox();
            this.conk = new System.Windows.Forms.PictureBox();
            this.crystalBepis = new System.Windows.Forms.PictureBox();
            this.bepis = new System.Windows.Forms.PictureBox();
            this.bepisPrice = new System.Windows.Forms.Label();
            this.cBepisPrice = new System.Windows.Forms.Label();
            this.conkPrice = new System.Windows.Forms.Label();
            this.pepperPrice = new System.Windows.Forms.Label();
            this.waterPrice = new System.Windows.Forms.Label();
            this.bepisRemain = new System.Windows.Forms.Label();
            this.cBepisRemain = new System.Windows.Forms.Label();
            this.conkRemain = new System.Windows.Forms.Label();
            this.pepperRemain = new System.Windows.Forms.Label();
            this.waterRemain = new System.Windows.Forms.Label();
            this.TSales = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.water)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pepper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.conk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.crystalBepis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bepis)).BeginInit();
            this.SuspendLayout();
            // 
            // bepisName
            // 
            this.bepisName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bepisName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bepisName.Location = new System.Drawing.Point(13, 13);
            this.bepisName.Name = "bepisName";
            this.bepisName.Size = new System.Drawing.Size(200, 100);
            this.bepisName.TabIndex = 0;
            this.bepisName.Text = "Bepis";
            // 
            // cBepisName
            // 
            this.cBepisName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.cBepisName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cBepisName.Location = new System.Drawing.Point(219, 13);
            this.cBepisName.Name = "cBepisName";
            this.cBepisName.Size = new System.Drawing.Size(200, 100);
            this.cBepisName.TabIndex = 1;
            this.cBepisName.Text = "Crystal Bepis";
            // 
            // conkName
            // 
            this.conkName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.conkName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conkName.Location = new System.Drawing.Point(13, 122);
            this.conkName.Name = "conkName";
            this.conkName.Size = new System.Drawing.Size(200, 100);
            this.conkName.TabIndex = 2;
            this.conkName.Text = "Conk";
            // 
            // pepperName
            // 
            this.pepperName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pepperName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pepperName.Location = new System.Drawing.Point(219, 122);
            this.pepperName.Name = "pepperName";
            this.pepperName.Size = new System.Drawing.Size(200, 100);
            this.pepperName.TabIndex = 3;
            this.pepperName.Text = "Pepper PhD.";
            // 
            // waterName
            // 
            this.waterName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.waterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waterName.Location = new System.Drawing.Point(12, 231);
            this.waterName.Name = "waterName";
            this.waterName.Size = new System.Drawing.Size(200, 100);
            this.waterName.TabIndex = 4;
            this.waterName.Text = "Hill Water";
            // 
            // salesLabel
            // 
            this.salesLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.salesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salesLabel.Location = new System.Drawing.Point(219, 231);
            this.salesLabel.Name = "salesLabel";
            this.salesLabel.Size = new System.Drawing.Size(200, 100);
            this.salesLabel.TabIndex = 5;
            this.salesLabel.Text = "Total Sales";
            this.salesLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // water
            // 
            this.water.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.water.Image = global::VendingMachineGoodman.Properties.Resources.Mountain_Dew;
            this.water.Location = new System.Drawing.Point(16, 249);
            this.water.Name = "water";
            this.water.Size = new System.Drawing.Size(80, 80);
            this.water.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.water.TabIndex = 10;
            this.water.TabStop = false;
            this.water.Click += new System.EventHandler(this.water_Click);
            // 
            // pepper
            // 
            this.pepper.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pepper.Image = global::VendingMachineGoodman.Properties.Resources.Dr__Pepper_PhD;
            this.pepper.Location = new System.Drawing.Point(221, 139);
            this.pepper.Name = "pepper";
            this.pepper.Size = new System.Drawing.Size(80, 80);
            this.pepper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pepper.TabIndex = 9;
            this.pepper.TabStop = false;
            this.pepper.Click += new System.EventHandler(this.pepper_Click);
            // 
            // conk
            // 
            this.conk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.conk.Image = global::VendingMachineGoodman.Properties.Resources.Conk;
            this.conk.Location = new System.Drawing.Point(16, 139);
            this.conk.Name = "conk";
            this.conk.Size = new System.Drawing.Size(80, 80);
            this.conk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.conk.TabIndex = 8;
            this.conk.TabStop = false;
            this.conk.Click += new System.EventHandler(this.conk_Click);
            // 
            // crystalBepis
            // 
            this.crystalBepis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalBepis.Image = global::VendingMachineGoodman.Properties.Resources.crystalBepis;
            this.crystalBepis.Location = new System.Drawing.Point(221, 30);
            this.crystalBepis.Name = "crystalBepis";
            this.crystalBepis.Size = new System.Drawing.Size(80, 80);
            this.crystalBepis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.crystalBepis.TabIndex = 7;
            this.crystalBepis.TabStop = false;
            this.crystalBepis.Click += new System.EventHandler(this.crystalBepis_Click);
            // 
            // bepis
            // 
            this.bepis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bepis.Image = global::VendingMachineGoodman.Properties.Resources.BepisTime;
            this.bepis.Location = new System.Drawing.Point(16, 30);
            this.bepis.Name = "bepis";
            this.bepis.Size = new System.Drawing.Size(80, 80);
            this.bepis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bepis.TabIndex = 6;
            this.bepis.TabStop = false;
            this.bepis.Click += new System.EventHandler(this.bepis_Click);
            // 
            // bepisPrice
            // 
            this.bepisPrice.AutoSize = true;
            this.bepisPrice.Location = new System.Drawing.Point(103, 30);
            this.bepisPrice.Name = "bepisPrice";
            this.bepisPrice.Size = new System.Drawing.Size(34, 13);
            this.bepisPrice.TabIndex = 11;
            this.bepisPrice.Text = "$1.50";
            // 
            // cBepisPrice
            // 
            this.cBepisPrice.AutoSize = true;
            this.cBepisPrice.Location = new System.Drawing.Point(307, 30);
            this.cBepisPrice.Name = "cBepisPrice";
            this.cBepisPrice.Size = new System.Drawing.Size(46, 13);
            this.cBepisPrice.TabIndex = 12;
            this.cBepisPrice.Text = "$200.00";
            // 
            // conkPrice
            // 
            this.conkPrice.AutoSize = true;
            this.conkPrice.Location = new System.Drawing.Point(103, 139);
            this.conkPrice.Name = "conkPrice";
            this.conkPrice.Size = new System.Drawing.Size(46, 13);
            this.conkPrice.TabIndex = 13;
            this.conkPrice.Text = "$150.00";
            // 
            // pepperPrice
            // 
            this.pepperPrice.AutoSize = true;
            this.pepperPrice.Location = new System.Drawing.Point(307, 139);
            this.pepperPrice.Name = "pepperPrice";
            this.pepperPrice.Size = new System.Drawing.Size(46, 13);
            this.pepperPrice.TabIndex = 14;
            this.pepperPrice.Text = "$150.00";
            // 
            // waterPrice
            // 
            this.waterPrice.AutoSize = true;
            this.waterPrice.Location = new System.Drawing.Point(103, 249);
            this.waterPrice.Name = "waterPrice";
            this.waterPrice.Size = new System.Drawing.Size(46, 13);
            this.waterPrice.TabIndex = 15;
            this.waterPrice.Text = "$100.00";
            // 
            // bepisRemain
            // 
            this.bepisRemain.Location = new System.Drawing.Point(103, 62);
            this.bepisRemain.Name = "bepisRemain";
            this.bepisRemain.Size = new System.Drawing.Size(109, 48);
            this.bepisRemain.TabIndex = 16;
            this.bepisRemain.Text = "Drinks Left:";
            this.bepisRemain.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // cBepisRemain
            // 
            this.cBepisRemain.Location = new System.Drawing.Point(308, 62);
            this.cBepisRemain.Name = "cBepisRemain";
            this.cBepisRemain.Size = new System.Drawing.Size(109, 48);
            this.cBepisRemain.TabIndex = 17;
            this.cBepisRemain.Text = "Drinks Left:";
            this.cBepisRemain.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // conkRemain
            // 
            this.conkRemain.Location = new System.Drawing.Point(103, 171);
            this.conkRemain.Name = "conkRemain";
            this.conkRemain.Size = new System.Drawing.Size(109, 48);
            this.conkRemain.TabIndex = 18;
            this.conkRemain.Text = "Drinks Left:";
            this.conkRemain.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pepperRemain
            // 
            this.pepperRemain.Location = new System.Drawing.Point(307, 171);
            this.pepperRemain.Name = "pepperRemain";
            this.pepperRemain.Size = new System.Drawing.Size(109, 48);
            this.pepperRemain.TabIndex = 19;
            this.pepperRemain.Text = "Drinks Left:";
            this.pepperRemain.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // waterRemain
            // 
            this.waterRemain.Location = new System.Drawing.Point(102, 281);
            this.waterRemain.Name = "waterRemain";
            this.waterRemain.Size = new System.Drawing.Size(109, 48);
            this.waterRemain.TabIndex = 20;
            this.waterRemain.Text = "Drinks Left:";
            this.waterRemain.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // TSales
            // 
            this.TSales.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TSales.Location = new System.Drawing.Point(298, 259);
            this.TSales.Name = "TSales";
            this.TSales.Size = new System.Drawing.Size(41, 16);
            this.TSales.TabIndex = 21;
            this.TSales.Text = "$0.00";
            this.TSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label18.Location = new System.Drawing.Point(135, 80);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 16);
            this.label18.TabIndex = 22;
            this.label18.Text = "20";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label19.Location = new System.Drawing.Point(340, 190);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 16);
            this.label19.TabIndex = 23;
            this.label19.Text = "20";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label20.Location = new System.Drawing.Point(340, 80);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 16);
            this.label20.TabIndex = 23;
            this.label20.Text = "20";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label21.Location = new System.Drawing.Point(135, 190);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 16);
            this.label21.TabIndex = 24;
            this.label21.Text = "20";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label22.Location = new System.Drawing.Point(135, 300);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 16);
            this.label22.TabIndex = 25;
            this.label22.Text = "20";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(12, 345);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(405, 23);
            this.exitButton.TabIndex = 26;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.TSales);
            this.Controls.Add(this.waterRemain);
            this.Controls.Add(this.pepperRemain);
            this.Controls.Add(this.conkRemain);
            this.Controls.Add(this.cBepisRemain);
            this.Controls.Add(this.bepisRemain);
            this.Controls.Add(this.waterPrice);
            this.Controls.Add(this.pepperPrice);
            this.Controls.Add(this.conkPrice);
            this.Controls.Add(this.cBepisPrice);
            this.Controls.Add(this.bepisPrice);
            this.Controls.Add(this.water);
            this.Controls.Add(this.pepper);
            this.Controls.Add(this.conk);
            this.Controls.Add(this.crystalBepis);
            this.Controls.Add(this.bepis);
            this.Controls.Add(this.salesLabel);
            this.Controls.Add(this.waterName);
            this.Controls.Add(this.pepperName);
            this.Controls.Add(this.conkName);
            this.Controls.Add(this.cBepisName);
            this.Controls.Add(this.bepisName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.water)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pepper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.conk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.crystalBepis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bepis)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label bepisName;
        private System.Windows.Forms.Label cBepisName;
        private System.Windows.Forms.Label conkName;
        private System.Windows.Forms.Label pepperName;
        private System.Windows.Forms.Label waterName;
        private System.Windows.Forms.Label salesLabel;
        private System.Windows.Forms.PictureBox bepis;
        private System.Windows.Forms.PictureBox crystalBepis;
        private System.Windows.Forms.PictureBox conk;
        private System.Windows.Forms.PictureBox pepper;
        private System.Windows.Forms.PictureBox water;
        private System.Windows.Forms.Label bepisPrice;
        private System.Windows.Forms.Label cBepisPrice;
        private System.Windows.Forms.Label conkPrice;
        private System.Windows.Forms.Label pepperPrice;
        private System.Windows.Forms.Label waterPrice;
        private System.Windows.Forms.Label bepisRemain;
        private System.Windows.Forms.Label cBepisRemain;
        private System.Windows.Forms.Label conkRemain;
        private System.Windows.Forms.Label pepperRemain;
        private System.Windows.Forms.Label waterRemain;
        private System.Windows.Forms.Label TSales;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button exitButton;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace VendingMachineGoodman
{
    public partial class Form1 : Form
    {
        public Form1()
        {


        }

        private void setQuantity() {
            try
            {
                StreamReader inputFile;
                string line;
                int count = 0;
                int total;

                char[] delim = { ',' };

                inputFile = File.OpenText("Quantity.txt");

                while (!inputFile.EndOfStream)
                {

                    count++;

                    line = inputFile.ReadLine();

                    string[] tokens = line.Split(delim);

                    total = 0;

                    foreach (string str in tokens)
                    {

                        total += int.Parse(str);
                    }
                }
                inputFile.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

                    const int SIZE = 5;

                    int[,] sodas = new int[SIZE, 2];

            for (int x = 0; x < SIZE; x++)
            {
                sodas[x, 1] = 20;
            }
        }
        private void bepis_Click(object sender, EventArgs e)
        {
            
        }

        private void crystalBepis_Click(object sender, EventArgs e)
        {

        }

        private void conk_Click(object sender, EventArgs e)
        {

        }

        private void pepper_Click(object sender, EventArgs e)
        {

        }

        private void water_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

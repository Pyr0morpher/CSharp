﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextBoxDemoGoodman
{
    public partial class TextBoxDemoGoodman : Form
    {
        public TextBoxDemoGoodman()
        {
            InitializeComponent();
        }

        private void readInputButton_Click(object sender, EventArgs e)
        {
            string output = inputTextBox.Text;
            outputLabel.Text = output;
        }

     

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

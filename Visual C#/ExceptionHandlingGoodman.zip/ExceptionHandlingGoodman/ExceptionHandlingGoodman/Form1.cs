﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExceptionHandlingGoodman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            decimal originalPrice, discountPercentage, discountAmount,salePrice; //og price, discount percentage, discount amount, sales price

            //gets the item's original price
            if (decimal.TryParse(originalPriceTextBox.Text, out originalPrice))
            {
                originalPriceTextBox.Text = originalPrice.ToString();

            }
            else
            {
                MessageBox.Show("ERROR: Input a number");
            }
            if (decimal.TryParse(discountPriceTextBox.Text, out discountPercentage))
            {
                discountPriceTextBox.Text = discountPercentage.ToString();

            }
            else
            {
                MessageBox.Show("ERROR: Input a number");
            }
            //Move the percentage's decimal point left two sapces.
            discountPercentage = discountPercentage / 100;

            //Calculate the amount of the discount.
            discountAmount = originalPrice * discountPercentage;

            //calculate the sale price
            salePrice = originalPrice - discountAmount;

            //displays the sales price
            salesLabel.Text = salePrice.ToString("c");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

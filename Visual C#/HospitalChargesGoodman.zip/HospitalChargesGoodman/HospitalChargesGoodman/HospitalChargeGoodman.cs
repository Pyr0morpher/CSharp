﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalChargesGoodman
{
    public partial class HospitalChargeGoodman : Form
    {
        public HospitalChargeGoodman()
        {
            InitializeComponent();
        }

        const decimal DAILY = 350;
        int numDays;
        decimal totalDaily;
        decimal totalMisc;
        decimal totalCost;

        private void calcButton_Click(object sender, EventArgs e)
        {
            calcStayCharges();
            calcMiscCharges();
            calcTotalCharges();
            totalLabel2.Text= "$" + totalCost.ToString();
        }

        //Calculates and returns the base daily hospital charge times the number of days spent in the hospital
        private void calcStayCharges() {

            if (int.TryParse(daysTextBox.Text, out numDays))
            {
                totalDaily = numDays * DAILY;
            }
            else
            {
                MessageBox.Show("ERROR: Enter # of days as a whole number.");
            }

        }

        //Calcualates and returns the cost of all Misc services
        private void calcMiscCharges() {

            //Surgery
            decimal.TryParse(surgTextBox.Text, out decimal surgCost);

            //Lab
            decimal.TryParse(labTextBox.Text, out decimal labCost);

            //Medicine
            decimal.TryParse(medTextBox.Text, out decimal medCost);

            //Rehab
            decimal.TryParse(rehabTextBox.Text, out decimal rehabCost);

            totalMisc = surgCost + labCost + medCost + rehabCost;

            
        }

        //Calculates Total
        private void calcTotalCharges()
        {
            totalCost = totalDaily + totalMisc;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

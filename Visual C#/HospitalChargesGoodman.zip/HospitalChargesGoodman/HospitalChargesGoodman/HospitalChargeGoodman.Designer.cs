﻿namespace HospitalChargesGoodman
{
    partial class HospitalChargeGoodman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HospitalChargeGoodman));
            this.hospitalChargesBox = new System.Windows.Forms.GroupBox();
            this.rehabTextBox = new System.Windows.Forms.TextBox();
            this.medTextBox = new System.Windows.Forms.TextBox();
            this.labTextBox = new System.Windows.Forms.TextBox();
            this.surgTextBox = new System.Windows.Forms.TextBox();
            this.daysTextBox = new System.Windows.Forms.TextBox();
            this.rehabLabel = new System.Windows.Forms.Label();
            this.labLabel = new System.Windows.Forms.Label();
            this.surgLabel = new System.Windows.Forms.Label();
            this.medLabel = new System.Windows.Forms.Label();
            this.spentLabel = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.totalLabel = new System.Windows.Forms.Label();
            this.totalLabel2 = new System.Windows.Forms.Label();
            this.hospitalChargesBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // hospitalChargesBox
            // 
            this.hospitalChargesBox.Controls.Add(this.rehabTextBox);
            this.hospitalChargesBox.Controls.Add(this.medTextBox);
            this.hospitalChargesBox.Controls.Add(this.labTextBox);
            this.hospitalChargesBox.Controls.Add(this.surgTextBox);
            this.hospitalChargesBox.Controls.Add(this.daysTextBox);
            this.hospitalChargesBox.Controls.Add(this.rehabLabel);
            this.hospitalChargesBox.Controls.Add(this.labLabel);
            this.hospitalChargesBox.Controls.Add(this.surgLabel);
            this.hospitalChargesBox.Controls.Add(this.medLabel);
            this.hospitalChargesBox.Controls.Add(this.spentLabel);
            this.hospitalChargesBox.Location = new System.Drawing.Point(13, 13);
            this.hospitalChargesBox.Name = "hospitalChargesBox";
            this.hospitalChargesBox.Size = new System.Drawing.Size(244, 164);
            this.hospitalChargesBox.TabIndex = 0;
            this.hospitalChargesBox.TabStop = false;
            this.hospitalChargesBox.Text = "Hospital Charges";
            // 
            // rehabTextBox
            // 
            this.rehabTextBox.Location = new System.Drawing.Point(96, 137);
            this.rehabTextBox.Name = "rehabTextBox";
            this.rehabTextBox.Size = new System.Drawing.Size(140, 20);
            this.rehabTextBox.TabIndex = 9;
            // 
            // medTextBox
            // 
            this.medTextBox.Location = new System.Drawing.Point(96, 107);
            this.medTextBox.Name = "medTextBox";
            this.medTextBox.Size = new System.Drawing.Size(140, 20);
            this.medTextBox.TabIndex = 8;
            // 
            // labTextBox
            // 
            this.labTextBox.Location = new System.Drawing.Point(96, 77);
            this.labTextBox.Name = "labTextBox";
            this.labTextBox.Size = new System.Drawing.Size(140, 20);
            this.labTextBox.TabIndex = 7;
            // 
            // surgTextBox
            // 
            this.surgTextBox.Location = new System.Drawing.Point(96, 47);
            this.surgTextBox.Name = "surgTextBox";
            this.surgTextBox.Size = new System.Drawing.Size(140, 20);
            this.surgTextBox.TabIndex = 6;
            // 
            // daysTextBox
            // 
            this.daysTextBox.Location = new System.Drawing.Point(96, 17);
            this.daysTextBox.Name = "daysTextBox";
            this.daysTextBox.Size = new System.Drawing.Size(140, 20);
            this.daysTextBox.TabIndex = 5;
            // 
            // rehabLabel
            // 
            this.rehabLabel.AutoSize = true;
            this.rehabLabel.Location = new System.Drawing.Point(7, 140);
            this.rehabLabel.Name = "rehabLabel";
            this.rehabLabel.Size = new System.Drawing.Size(63, 13);
            this.rehabLabel.TabIndex = 4;
            this.rehabLabel.Text = "Rehab Fee:";
            // 
            // labLabel
            // 
            this.labLabel.AutoSize = true;
            this.labLabel.Location = new System.Drawing.Point(7, 80);
            this.labLabel.Name = "labLabel";
            this.labLabel.Size = new System.Drawing.Size(70, 13);
            this.labLabel.TabIndex = 3;
            this.labLabel.Text = "Lab Charges:";
            // 
            // surgLabel
            // 
            this.surgLabel.AutoSize = true;
            this.surgLabel.Location = new System.Drawing.Point(7, 50);
            this.surgLabel.Name = "surgLabel";
            this.surgLabel.Size = new System.Drawing.Size(67, 13);
            this.surgLabel.TabIndex = 2;
            this.surgLabel.Text = "Surgury Fee:";
            // 
            // medLabel
            // 
            this.medLabel.AutoSize = true;
            this.medLabel.Location = new System.Drawing.Point(7, 110);
            this.medLabel.Name = "medLabel";
            this.medLabel.Size = new System.Drawing.Size(73, 13);
            this.medLabel.TabIndex = 1;
            this.medLabel.Text = "Med Charges:";
            // 
            // spentLabel
            // 
            this.spentLabel.AutoSize = true;
            this.spentLabel.Location = new System.Drawing.Point(7, 20);
            this.spentLabel.Name = "spentLabel";
            this.spentLabel.Size = new System.Drawing.Size(65, 13);
            this.spentLabel.TabIndex = 0;
            this.spentLabel.Text = "Days Spent:";
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(13, 183);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(244, 58);
            this.calcButton.TabIndex = 2;
            this.calcButton.Text = "&Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(267, 183);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(157, 58);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLabel.Location = new System.Drawing.Point(263, 86);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(54, 20);
            this.totalLabel.TabIndex = 4;
            this.totalLabel.Text = "Total:";
            // 
            // totalLabel2
            // 
            this.totalLabel2.AutoSize = true;
            this.totalLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLabel2.Location = new System.Drawing.Point(323, 86);
            this.totalLabel2.Name = "totalLabel2";
            this.totalLabel2.Size = new System.Drawing.Size(29, 20);
            this.totalLabel2.TabIndex = 5;
            this.totalLabel2.Text = "$0";
            // 
            // HospitalChargeGoodman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(440, 253);
            this.Controls.Add(this.totalLabel2);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.hospitalChargesBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HospitalChargeGoodman";
            this.Text = "Hospital Bill";
            this.hospitalChargesBox.ResumeLayout(false);
            this.hospitalChargesBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox hospitalChargesBox;
        private System.Windows.Forms.TextBox rehabTextBox;
        private System.Windows.Forms.TextBox medTextBox;
        private System.Windows.Forms.TextBox labTextBox;
        private System.Windows.Forms.TextBox surgTextBox;
        private System.Windows.Forms.TextBox daysTextBox;
        private System.Windows.Forms.Label rehabLabel;
        private System.Windows.Forms.Label labLabel;
        private System.Windows.Forms.Label surgLabel;
        private System.Windows.Forms.Label medLabel;
        private System.Windows.Forms.Label spentLabel;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label totalLabel2;
    }
}


﻿namespace GoodmanArithmetic
{
    partial class GoodmanArithmetic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.addBox = new System.Windows.Forms.TextBox();
            this.subBox = new System.Windows.Forms.TextBox();
            this.multBox = new System.Windows.Forms.TextBox();
            this.modBox = new System.Windows.Forms.TextBox();
            this.divBox = new System.Windows.Forms.TextBox();
            this.incBox = new System.Windows.Forms.TextBox();
            this.decBox = new System.Windows.Forms.TextBox();
            this.showButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Addition:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Subtaction:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mulitlication:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Division:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Modulous:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Increment:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 268);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Decrement:";
            // 
            // addBox
            // 
            this.addBox.Location = new System.Drawing.Point(111, 35);
            this.addBox.Name = "addBox";
            this.addBox.Size = new System.Drawing.Size(100, 20);
            this.addBox.TabIndex = 7;
            // 
            // subBox
            // 
            this.subBox.Location = new System.Drawing.Point(111, 75);
            this.subBox.Name = "subBox";
            this.subBox.Size = new System.Drawing.Size(100, 20);
            this.subBox.TabIndex = 8;
            // 
            // multBox
            // 
            this.multBox.Location = new System.Drawing.Point(111, 114);
            this.multBox.Name = "multBox";
            this.multBox.Size = new System.Drawing.Size(100, 20);
            this.multBox.TabIndex = 9;
            // 
            // modBox
            // 
            this.modBox.Location = new System.Drawing.Point(111, 193);
            this.modBox.Name = "modBox";
            this.modBox.Size = new System.Drawing.Size(100, 20);
            this.modBox.TabIndex = 10;
            // 
            // divBox
            // 
            this.divBox.Location = new System.Drawing.Point(111, 152);
            this.divBox.Name = "divBox";
            this.divBox.Size = new System.Drawing.Size(100, 20);
            this.divBox.TabIndex = 10;
            // 
            // incBox
            // 
            this.incBox.Location = new System.Drawing.Point(111, 230);
            this.incBox.Name = "incBox";
            this.incBox.Size = new System.Drawing.Size(100, 20);
            this.incBox.TabIndex = 11;
            // 
            // decBox
            // 
            this.decBox.Location = new System.Drawing.Point(111, 268);
            this.decBox.Name = "decBox";
            this.decBox.Size = new System.Drawing.Size(100, 20);
            this.decBox.TabIndex = 12;
            // 
            // showButton
            // 
            this.showButton.Location = new System.Drawing.Point(91, 335);
            this.showButton.Name = "showButton";
            this.showButton.Size = new System.Drawing.Size(75, 23);
            this.showButton.TabIndex = 13;
            this.showButton.Text = "Show";
            this.showButton.UseVisualStyleBackColor = true;
            this.showButton.Click += new System.EventHandler(this.showButton_Click);
            // 
            // GoodmanArithmetic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(288, 370);
            this.Controls.Add(this.showButton);
            this.Controls.Add(this.decBox);
            this.Controls.Add(this.incBox);
            this.Controls.Add(this.divBox);
            this.Controls.Add(this.modBox);
            this.Controls.Add(this.multBox);
            this.Controls.Add(this.subBox);
            this.Controls.Add(this.addBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "GoodmanArithmetic";
            this.Text = "Arithemic Operations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox addBox;
        private System.Windows.Forms.TextBox subBox;
        private System.Windows.Forms.TextBox multBox;
        private System.Windows.Forms.TextBox modBox;
        private System.Windows.Forms.TextBox divBox;
        private System.Windows.Forms.TextBox incBox;
        private System.Windows.Forms.TextBox decBox;
        private System.Windows.Forms.Button showButton;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoodmanArithmetic
{
    public partial class GoodmanArithmetic : Form
    {
        public GoodmanArithmetic()
        {
            InitializeComponent();
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            int add = 4 + 5;
            string dispAdd = "4 + 5 = " + add.ToString();
            addBox.Text = dispAdd;

            int sub = 4 - 5;
            string dispSub = "4 - 5 = " + sub.ToString();
            subBox.Text = dispSub;

            int mult = 4 * 5;
            string dispMult = " 4 * 5 = " + mult.ToString();
            multBox.Text = dispMult;

            int div = 4 / 2;
            string dispDiv = "4 / 2 = " + div.ToString();
            divBox.Text = dispDiv;

            int mod = 12 % 5;
            string dispMod = "12 % 5 = " + mod.ToString();
            modBox.Text = dispMod;

            int inc = 4;
            inc++;
            string dispInc = "4++ = " + inc++.ToString();
            incBox.Text = dispInc;

            int dec = 4;
            dec--;
            string dispDec = "4-- = " + dec.ToString();
            decBox.Text = dispDec;
        }
    }
}

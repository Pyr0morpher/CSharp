﻿namespace TicTacToeGoodman
{
    partial class TicTacToeGoodman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.newGameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.oneOne = new System.Windows.Forms.Label();
            this.oneTwo = new System.Windows.Forms.Label();
            this.oneThree = new System.Windows.Forms.Label();
            this.twoOne = new System.Windows.Forms.Label();
            this.twoTwo = new System.Windows.Forms.Label();
            this.twoThree = new System.Windows.Forms.Label();
            this.threeOne = new System.Windows.Forms.Label();
            this.threeTwo = new System.Windows.Forms.Label();
            this.threeThree = new System.Windows.Forms.Label();
            this.winLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // newGameButton
            // 
            this.newGameButton.Location = new System.Drawing.Point(12, 314);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(123, 23);
            this.newGameButton.TabIndex = 0;
            this.newGameButton.Text = "&Generate";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(149, 314);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(123, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // oneOne
            // 
            this.oneOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.oneOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneOne.Location = new System.Drawing.Point(12, 9);
            this.oneOne.Name = "oneOne";
            this.oneOne.Size = new System.Drawing.Size(75, 75);
            this.oneOne.TabIndex = 2;
            // 
            // oneTwo
            // 
            this.oneTwo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.oneTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneTwo.Location = new System.Drawing.Point(104, 9);
            this.oneTwo.Name = "oneTwo";
            this.oneTwo.Size = new System.Drawing.Size(75, 75);
            this.oneTwo.TabIndex = 3;
            // 
            // oneThree
            // 
            this.oneThree.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.oneThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneThree.Location = new System.Drawing.Point(197, 9);
            this.oneThree.Name = "oneThree";
            this.oneThree.Size = new System.Drawing.Size(75, 75);
            this.oneThree.TabIndex = 4;
            // 
            // twoOne
            // 
            this.twoOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.twoOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoOne.Location = new System.Drawing.Point(12, 97);
            this.twoOne.Name = "twoOne";
            this.twoOne.Size = new System.Drawing.Size(75, 75);
            this.twoOne.TabIndex = 5;
            // 
            // twoTwo
            // 
            this.twoTwo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.twoTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoTwo.Location = new System.Drawing.Point(104, 97);
            this.twoTwo.Name = "twoTwo";
            this.twoTwo.Size = new System.Drawing.Size(75, 75);
            this.twoTwo.TabIndex = 6;
            // 
            // twoThree
            // 
            this.twoThree.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.twoThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoThree.Location = new System.Drawing.Point(197, 97);
            this.twoThree.Name = "twoThree";
            this.twoThree.Size = new System.Drawing.Size(75, 75);
            this.twoThree.TabIndex = 7;
            // 
            // threeOne
            // 
            this.threeOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.threeOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threeOne.Location = new System.Drawing.Point(12, 185);
            this.threeOne.Name = "threeOne";
            this.threeOne.Size = new System.Drawing.Size(75, 75);
            this.threeOne.TabIndex = 8;
            // 
            // threeTwo
            // 
            this.threeTwo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.threeTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threeTwo.Location = new System.Drawing.Point(104, 185);
            this.threeTwo.Name = "threeTwo";
            this.threeTwo.Size = new System.Drawing.Size(75, 75);
            this.threeTwo.TabIndex = 9;
            // 
            // threeThree
            // 
            this.threeThree.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.threeThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threeThree.Location = new System.Drawing.Point(197, 185);
            this.threeThree.Name = "threeThree";
            this.threeThree.Size = new System.Drawing.Size(75, 75);
            this.threeThree.TabIndex = 10;
            // 
            // winLabel
            // 
            this.winLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.winLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.winLabel.Location = new System.Drawing.Point(12, 271);
            this.winLabel.Name = "winLabel";
            this.winLabel.Size = new System.Drawing.Size(260, 23);
            this.winLabel.TabIndex = 11;
            this.winLabel.Text = "Nobody Wins";
            this.winLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TicTacToeGoodman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 361);
            this.Controls.Add(this.winLabel);
            this.Controls.Add(this.threeThree);
            this.Controls.Add(this.threeTwo);
            this.Controls.Add(this.threeOne);
            this.Controls.Add(this.twoThree);
            this.Controls.Add(this.twoTwo);
            this.Controls.Add(this.twoOne);
            this.Controls.Add(this.oneThree);
            this.Controls.Add(this.oneTwo);
            this.Controls.Add(this.oneOne);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.newGameButton);
            this.Name = "TicTacToeGoodman";
            this.Text = "Tic Tac Toe";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button newGameButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label oneOne;
        private System.Windows.Forms.Label oneTwo;
        private System.Windows.Forms.Label oneThree;
        private System.Windows.Forms.Label twoOne;
        private System.Windows.Forms.Label twoTwo;
        private System.Windows.Forms.Label twoThree;
        private System.Windows.Forms.Label threeOne;
        private System.Windows.Forms.Label threeTwo;
        private System.Windows.Forms.Label threeThree;
        private System.Windows.Forms.Label winLabel;
    }
}


﻿/** =========================================================

 Corbin Goodman
 Windows 10
 Microsoft Visual Studio 2017
 CIS 169 C# 
 Module 7 Tic Tac Toe
 2D Array that plays Tic Tac Toe with itself
 Academic Honesty:
 I attest that this is my original work.
 I have not used unauthorized source code, either modified or unmodified.
 I have not given other fellow student(s) access to my program.

=========================================================== **/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToeGoodman
{
    public partial class TicTacToeGoodman : Form
    {
        public TicTacToeGoodman()
        {
            InitializeComponent();
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            const int SIZE = 9;
            int[,] ticArray = new int[SIZE, SIZE];
            Label[] labels = new Label[SIZE] {oneOne, oneTwo, oneThree, twoOne, twoTwo, twoThree, threeOne, threeTwo, threeThree};
            int i = 0;
            Random rnd = new Random();

            //fills the arrays for row, collumn, and labels

            for (int row = 0; row < 3;row++)
            {


                for (int col = 0; col < 3; col++)
                {

                    int random;
                    random = rnd.Next(1, 3);

                    ticArray[row, col] = random;

                        if (ticArray[row, col] == 1)
                        {

                            labels[i].Text = "X";

                        }
                        else
                        {

                            labels[i].Text = "O";

                        }

                    i++;

                }
                
            }
            

            //A giant block of code to see who wins

            if (labels[0].Text == labels[1].Text && labels[1].Text == labels[2].Text)
            {
                winLabel.Text = labels[0].Text + " Wins!";
            }
            else if (labels[3].Text == labels[4].Text && labels[4].Text == labels[5].Text)
            {
                winLabel.Text = labels[3].Text + " Wins!";
            }
            else if (labels[6].Text == labels[7].Text && labels[7].Text == labels[8].Text)
            {
                winLabel.Text = labels[6].Text + " Wins!";
            }
            else if (labels[0].Text == labels[3].Text && labels[3].Text == labels[6].Text)
            {
                winLabel.Text = labels[0].Text + " Wins!";
            }
            else if (labels[1].Text == labels[4].Text && labels[4].Text == labels[7].Text)
            {
                winLabel.Text = labels[1].Text + " Wins!";
            }
            else if (labels[2].Text == labels[5].Text && labels[5].Text == labels[8].Text)
            {
                winLabel.Text = labels[2].Text + " Wins!";
            }
            else if (labels[0].Text == labels[4].Text && labels[4].Text == labels[8].Text)
            {
                winLabel.Text = labels[0].Text + " Wins!";
            }
            else if (labels[2].Text == labels[4].Text && labels[4].Text == labels[6].Text)
            {
                winLabel.Text = labels[2].Text + " Wins!";
            }
            else
            {
                winLabel.Text = "Tie!";
            }

        }


        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

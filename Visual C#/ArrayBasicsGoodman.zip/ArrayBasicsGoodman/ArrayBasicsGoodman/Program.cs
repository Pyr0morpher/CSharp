﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayBasicsGoodman
{
    class Program
    {
        static void Main()
        {

            const int SIZE = 4;


            int[] corbin = new int[SIZE];
            int[] savian = new int[SIZE];
            int[] lucas = new int[SIZE];
            int[] zach = new int[SIZE];



            for (int x = 0; x < SIZE; x++)
            {

                Console.WriteLine("Input Score " + (x + 1) + " for the students: ");
                
                corbin[x] = int.Parse(Console.ReadLine());
                savian[x] = int.Parse(Console.ReadLine());
                lucas[x] = int.Parse(Console.ReadLine());
                zach[x] = int.Parse(Console.ReadLine());

            }

            Console.WriteLine("Student 1: " + corbin[0] + ", " + corbin[1] + ", " + corbin[2] + ", " + corbin[3]);

            Console.WriteLine("Student 2: " + savian[0] + ", " + savian[1] + ", " + savian[2] + ", " + savian[3]);

            Console.WriteLine("Student 3: " + lucas[0] + ", " + lucas[1] + ", " + lucas[2] + ", "+ lucas[3]);

            Console.WriteLine("Student 4: " + zach[0] + ", " + zach[1] + ", " + zach[2] + ", " + zach[3]);

            Console.ReadKey();

        }

    
    }
}


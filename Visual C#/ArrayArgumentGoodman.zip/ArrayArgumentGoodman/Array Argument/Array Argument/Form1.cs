﻿/** =========================================================

 Corbin Goodman
 Windows 10
 Microsoft Visual Studio 2017
 CIS 169 C# 
 Array Arguments
 Academic Honesty:
 I attest that this is my original work.
 I have not used unauthorized source code, either modified or unmodified.
 I have not given other fellow student(s) access to my program.

=========================================================== **/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Array_Argument
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] numbers = { 26, 56, 30, 51, 65, 56, 48, 61, 3, 47, 5, 25, 62, 55, 5 };

        // Click event handler for the goButton control.
        private void goButton_Click(object sender, EventArgs e)
        {

           
            // Display the array in the list box.
            outputListBox.Items.Add("The array's original contents:");
            foreach (int number in numbers)
            {
                outputListBox.Items.Add(number);
            }


        }

        //finds biggest value in the array and shows it in a message box.
        private void max()
        {
            int maxValue = numbers.Max();
            MessageBox.Show("Maximum Value = " + maxValue);
        }

        //finds smallest value in the array and shows it in a message box.
        private void min()
        {
            int minValue = numbers.Min();
            MessageBox.Show("Minimum Value = " + minValue);

        }

        // Click event handler for the exitButton control.
        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }

        private void maxButton_Click(object sender, EventArgs e)
        {
            max();
        }

        private void minButton_Click(object sender, EventArgs e)
        {
            min();
        }
    }
}

﻿namespace HelloWorld
{
    partial class FreeVBucks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FreeVBucks));
            this.scamButton = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // scamButton
            // 
            this.scamButton.BackColor = System.Drawing.Color.Fuchsia;
            this.scamButton.ForeColor = System.Drawing.SystemColors.Control;
            this.scamButton.Location = new System.Drawing.Point(419, 208);
            this.scamButton.Name = "scamButton";
            this.scamButton.Size = new System.Drawing.Size(105, 87);
            this.scamButton.TabIndex = 2;
            this.scamButton.Text = "CLICK FOR FREE V-BUCKS!!!";
            this.scamButton.UseVisualStyleBackColor = false;
            this.scamButton.Click += new System.EventHandler(this.scamButton_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FreeVBucks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HelloWorld.Properties.Resources.dbldpzwxuaa7as2;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.scamButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FreeVBucks";
            this.Text = "FREE V-BUCKS!!";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button scamButton;
        private System.Windows.Forms.Timer timer1;
    }
}


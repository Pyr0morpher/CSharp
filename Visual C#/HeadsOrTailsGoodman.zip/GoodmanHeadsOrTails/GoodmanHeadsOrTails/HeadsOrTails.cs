﻿/** =========================================================

 Corbin Goodman
 Windows 10
 Microsoft Visual Studio 2017
 CIS 169 C# 
 Module 2: Heads or Tails
 Press different buttons to flip the coin
 Academic Honesty:
 I attest that this is my original work.
 I have not used unauthorized source code, either modified or unmodified.
 I have not given other fellow student(s) access to my program.

=========================================================== **/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoodmanHeadsOrTails
{
    public partial class HeadsOrTails : Form
    {
        public HeadsOrTails()
        {
            InitializeComponent();
        }

        private void headsButton_Click(object sender, EventArgs e)
        {
            headsCoin.Visible = true;
            tailsCoin.Visible = false;
        }

        private void tailsButton_Click(object sender, EventArgs e)
        {
            tailsCoin.Visible = true;
            headsCoin.Visible = false;
        }
    }
}

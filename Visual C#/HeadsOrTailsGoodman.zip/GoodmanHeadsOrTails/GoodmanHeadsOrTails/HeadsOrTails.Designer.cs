﻿namespace GoodmanHeadsOrTails
{
    partial class HeadsOrTails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeadsOrTails));
            this.headsButton = new System.Windows.Forms.Button();
            this.tailsButton = new System.Windows.Forms.Button();
            this.tailsCoin = new System.Windows.Forms.PictureBox();
            this.headsCoin = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.tailsCoin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.headsCoin)).BeginInit();
            this.SuspendLayout();
            // 
            // headsButton
            // 
            this.headsButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.headsButton.Location = new System.Drawing.Point(5, 376);
            this.headsButton.Name = "headsButton";
            this.headsButton.Size = new System.Drawing.Size(179, 62);
            this.headsButton.TabIndex = 0;
            this.headsButton.Text = "Show Heads";
            this.headsButton.UseVisualStyleBackColor = true;
            this.headsButton.Click += new System.EventHandler(this.headsButton_Click);
            // 
            // tailsButton
            // 
            this.tailsButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tailsButton.Location = new System.Drawing.Point(190, 376);
            this.tailsButton.Name = "tailsButton";
            this.tailsButton.Size = new System.Drawing.Size(179, 62);
            this.tailsButton.TabIndex = 1;
            this.tailsButton.Text = "Show Tails";
            this.tailsButton.UseVisualStyleBackColor = true;
            this.tailsButton.Click += new System.EventHandler(this.tailsButton_Click);
            // 
            // tailsCoin
            // 
            this.tailsCoin.Image = global::GoodmanHeadsOrTails.Properties.Resources._51NyMaKLydL;
            this.tailsCoin.Location = new System.Drawing.Point(39, 47);
            this.tailsCoin.Name = "tailsCoin";
            this.tailsCoin.Size = new System.Drawing.Size(300, 296);
            this.tailsCoin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.tailsCoin.TabIndex = 4;
            this.tailsCoin.TabStop = false;
            // 
            // headsCoin
            // 
            this.headsCoin.Image = global::GoodmanHeadsOrTails.Properties.Resources._51xs7F_tP5L__SX425_;
            this.headsCoin.Location = new System.Drawing.Point(-4, 37);
            this.headsCoin.Name = "headsCoin";
            this.headsCoin.Size = new System.Drawing.Size(388, 319);
            this.headsCoin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.headsCoin.TabIndex = 3;
            this.headsCoin.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(381, 450);
            this.Controls.Add(this.tailsButton);
            this.Controls.Add(this.headsButton);
            this.Controls.Add(this.headsCoin);
            this.Controls.Add(this.tailsCoin);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Heads or Tails";
            ((System.ComponentModel.ISupportInitialize)(this.tailsCoin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.headsCoin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button headsButton;
        private System.Windows.Forms.Button tailsButton;
        private System.Windows.Forms.PictureBox headsCoin;
        private System.Windows.Forms.PictureBox tailsCoin;
    }
}


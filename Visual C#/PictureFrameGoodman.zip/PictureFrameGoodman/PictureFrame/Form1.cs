﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PictureFrame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showPic1_Click(object sender, EventArgs e)
        {
            pic1.BackgroundImage = imageList1.Images[0];
        }

        private void showPic2_Click(object sender, EventArgs e)
        {
            pic2.BackgroundImage = imageList1.Images[1];
        }

        private void showPic3_Click(object sender, EventArgs e)
        {
            pic3.BackgroundImage = imageList1.Images[2];
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

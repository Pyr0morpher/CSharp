﻿namespace PictureFrame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pic1 = new System.Windows.Forms.Panel();
            this.pic2 = new System.Windows.Forms.Panel();
            this.pic3 = new System.Windows.Forms.Panel();
            this.showPic1 = new System.Windows.Forms.Button();
            this.showPic2 = new System.Windows.Forms.Button();
            this.showPic3 = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // pic1
            // 
            this.pic1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pic1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic1.Location = new System.Drawing.Point(33, 33);
            this.pic1.Name = "pic1";
            this.pic1.Size = new System.Drawing.Size(82, 76);
            this.pic1.TabIndex = 0;
            // 
            // pic2
            // 
            this.pic2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pic2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic2.Location = new System.Drawing.Point(121, 33);
            this.pic2.Name = "pic2";
            this.pic2.Size = new System.Drawing.Size(82, 76);
            this.pic2.TabIndex = 1;
            // 
            // pic3
            // 
            this.pic3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pic3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic3.Location = new System.Drawing.Point(209, 33);
            this.pic3.Name = "pic3";
            this.pic3.Size = new System.Drawing.Size(82, 76);
            this.pic3.TabIndex = 1;
            // 
            // showPic1
            // 
            this.showPic1.Location = new System.Drawing.Point(33, 116);
            this.showPic1.Name = "showPic1";
            this.showPic1.Size = new System.Drawing.Size(82, 38);
            this.showPic1.TabIndex = 2;
            this.showPic1.Text = "Show Picture &1";
            this.showPic1.UseVisualStyleBackColor = true;
            this.showPic1.Click += new System.EventHandler(this.showPic1_Click);
            // 
            // showPic2
            // 
            this.showPic2.Location = new System.Drawing.Point(121, 116);
            this.showPic2.Name = "showPic2";
            this.showPic2.Size = new System.Drawing.Size(82, 38);
            this.showPic2.TabIndex = 3;
            this.showPic2.Text = "Show Picture &2";
            this.showPic2.UseVisualStyleBackColor = true;
            this.showPic2.Click += new System.EventHandler(this.showPic2_Click);
            // 
            // showPic3
            // 
            this.showPic3.Location = new System.Drawing.Point(209, 116);
            this.showPic3.Name = "showPic3";
            this.showPic3.Size = new System.Drawing.Size(82, 38);
            this.showPic3.TabIndex = 4;
            this.showPic3.Text = "Show Picture &3";
            this.showPic3.UseVisualStyleBackColor = true;
            this.showPic3.Click += new System.EventHandler(this.showPic3_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(121, 204);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(82, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "sal1.jpg");
            this.imageList1.Images.SetKeyName(1, "sal2.png");
            this.imageList1.Images.SetKeyName(2, "sal3.jpg");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 239);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showPic3);
            this.Controls.Add(this.showPic2);
            this.Controls.Add(this.showPic1);
            this.Controls.Add(this.pic3);
            this.Controls.Add(this.pic2);
            this.Controls.Add(this.pic1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pic1;
        private System.Windows.Forms.Panel pic2;
        private System.Windows.Forms.Panel pic3;
        private System.Windows.Forms.Button showPic1;
        private System.Windows.Forms.Button showPic2;
        private System.Windows.Forms.Button showPic3;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ImageList imageList1;
    }
}


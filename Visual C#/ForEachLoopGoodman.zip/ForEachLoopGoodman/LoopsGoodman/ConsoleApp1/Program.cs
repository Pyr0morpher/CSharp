﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
 class LoopsGoodman
        {
            public static void Main()
            {


            /*

                //~~~WHILE LOOP~~~

                const decimal SIZE = 6;
                decimal test = 1;
                decimal[] score = new decimal[SIZE];
                decimal scores;

            
                while(test <= 5 )	
                {

                Console.WriteLine("Score for test " + test + ":");

                    if (decimal.TryParse(Console.ReadLine(),out scores))
                    {

                        if (scores > 0 && scores < 100)
                        {
                            score[test] = scores;
                        }
                        else
                        {
                            Console.WriteLine("Error: Enter score from 1 through 100");
                        }
                    
                    }
                    else
                    {
                    Console.WriteLine("Error: Only use whole numbers");
                    }


                test++;


                }

                double combined = score[1] + score[2] + score[3] + score[4] + score[5];
                Console.WriteLine("Test Average = " + combined / 5);

             */

            /*

            //~~~DO WHILE LOOP~~~

            const decimal SIZE = 6;
            decimal test = 1;
            decimal[] score = new decimal[SIZE];
            decimal scores;

            do
            {
            Console.WriteLine("Score for test " + test + ":");

                if (decimal.TryParse(Console.ReadLine(),out scores))
                {


                    score[test] = scores;

                }
                else
                {
                Console.WriteLine("Error: Only use whole numbers");
                }


            test++;


            }
            while(test <= 5);

            double combined = score[1] + score[2] + score[3] + score[4] + score[5];
            Console.WriteLine("Test Average = " + combined / 5);
            */



             //FOR LOOP


            const int SIZE = 6;
            decimal[] score = new decimal[SIZE];
            decimal scores; 
            decimal total = 0;
            decimal average = 0;

            for (int test = 1; test <= 5; test++)
            {
            Console.WriteLine("Score for test " + test + ":");

                if (decimal.TryParse(Console.ReadLine(), out scores))
                {

                    if (scores > 0 && scores <= 100) 
                    {
                        score[test] = scores;
                    }
                    else
                    {
                        Console.WriteLine("Error: Enter score from 1 through 100");
                        test--;
                    }
                }
                else
                {
                    Console.WriteLine("Error: Only use numbers");
                    test--;
                }
            }

            foreach (decimal testScore in score)
            {
                total = testScore + testScore;

            }

            average = total / score.Length;

            ;

            Console.WriteLine("Test Average = " + decimal.Round(average, 2, MidpointRounding.AwayFromZero));


            }
    }
    }


﻿namespace GoodmanGuessingGame
{
    partial class GoodmanGuessingGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lowerRangeText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.upperRangeText = new System.Windows.Forms.TextBox();
            this.guessText = new System.Windows.Forms.TextBox();
            this.endLabel = new System.Windows.Forms.Label();
            this.guessButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Input Range:";
            // 
            // lowerRangeText
            // 
            this.lowerRangeText.Location = new System.Drawing.Point(88, 10);
            this.lowerRangeText.Name = "lowerRangeText";
            this.lowerRangeText.Size = new System.Drawing.Size(30, 20);
            this.lowerRangeText.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(126, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "to";
            // 
            // upperRangeText
            // 
            this.upperRangeText.Location = new System.Drawing.Point(149, 10);
            this.upperRangeText.Name = "upperRangeText";
            this.upperRangeText.Size = new System.Drawing.Size(31, 20);
            this.upperRangeText.TabIndex = 3;
            // 
            // guessText
            // 
            this.guessText.Location = new System.Drawing.Point(88, 86);
            this.guessText.Name = "guessText";
            this.guessText.Size = new System.Drawing.Size(92, 20);
            this.guessText.TabIndex = 4;
            // 
            // endLabel
            // 
            this.endLabel.AutoSize = true;
            this.endLabel.Location = new System.Drawing.Point(85, 152);
            this.endLabel.Name = "endLabel";
            this.endLabel.Size = new System.Drawing.Size(16, 13);
            this.endLabel.TabIndex = 5;
            this.endLabel.Text = "...";
            // 
            // guessButton
            // 
            this.guessButton.Location = new System.Drawing.Point(13, 182);
            this.guessButton.Name = "guessButton";
            this.guessButton.Size = new System.Drawing.Size(263, 23);
            this.guessButton.TabIndex = 6;
            this.guessButton.Text = "Guess";
            this.guessButton.UseVisualStyleBackColor = true;
            this.guessButton.Click += new System.EventHandler(this.guessButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Guess:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Is It Correct?:";
            // 
            // GoodmanGuessingGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(288, 217);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.guessButton);
            this.Controls.Add(this.endLabel);
            this.Controls.Add(this.guessText);
            this.Controls.Add(this.upperRangeText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lowerRangeText);
            this.Controls.Add(this.label1);
            this.Name = "GoodmanGuessingGame";
            this.Text = "Guessing Game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lowerRangeText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox upperRangeText;
        private System.Windows.Forms.TextBox guessText;
        private System.Windows.Forms.Label endLabel;
        private System.Windows.Forms.Button guessButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}


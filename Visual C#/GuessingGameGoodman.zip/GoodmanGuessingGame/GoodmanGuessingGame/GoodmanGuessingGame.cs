﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoodmanGuessingGame
{
    public partial class GoodmanGuessingGame : Form
    {
        public GoodmanGuessingGame()
        {
            InitializeComponent();
        }

        private void guessButton_Click(object sender, EventArgs e)
        {
            int lowerRange, upperRange, guess;
            Random rnd = new Random();


            if (int.TryParse(lowerRangeText.Text, out lowerRange))
            {

                if (int.TryParse(upperRangeText.Text, out upperRange))
                {

                    if (lowerRange >= 0 || upperRange >= 0)
                    {

                        endLabel.Text = ("Don't Use Less Than 1");

                    }

                    if (int.TryParse(guessText.Text, out guess))
                    {

                        if (guess > upperRange || guess < lowerRange)
                        {

                            endLabel.Text = ("Guess In The Range!");

                        }

                        int guessRange = rnd.Next(lowerRange, upperRange + 1);

                        if (guess > guessRange)
                        {

                            endLabel.Text = ("Too High!");

                        }
                        else if (guess < guessRange)
                        {

                            endLabel.Text = ("Too Low!");

                        }
                        else
                        {

                            endLabel.Text = ("Right On!");

                        }
                    }

                }


            }
        }
    }
}


﻿namespace StringDemo
{
    partial class GoodmanStringDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstLabel = new System.Windows.Forms.Label();
            this.lastLabel = new System.Windows.Forms.Label();
            this.fullLabel = new System.Windows.Forms.Label();
            this.outputLabel = new System.Windows.Forms.Label();
            this.firstTextBox = new System.Windows.Forms.TextBox();
            this.lastTextBox = new System.Windows.Forms.TextBox();
            this.nameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstLabel
            // 
            this.firstLabel.AutoSize = true;
            this.firstLabel.Location = new System.Drawing.Point(13, 43);
            this.firstLabel.Name = "firstLabel";
            this.firstLabel.Size = new System.Drawing.Size(88, 13);
            this.firstLabel.TabIndex = 0;
            this.firstLabel.Text = "Enter First Name:";
            // 
            // lastLabel
            // 
            this.lastLabel.AutoSize = true;
            this.lastLabel.Location = new System.Drawing.Point(13, 68);
            this.lastLabel.Name = "lastLabel";
            this.lastLabel.Size = new System.Drawing.Size(89, 13);
            this.lastLabel.TabIndex = 1;
            this.lastLabel.Text = "Enter Last Name:";
            // 
            // fullLabel
            // 
            this.fullLabel.AutoSize = true;
            this.fullLabel.Location = new System.Drawing.Point(19, 95);
            this.fullLabel.Name = "fullLabel";
            this.fullLabel.Size = new System.Drawing.Size(82, 13);
            this.fullLabel.TabIndex = 2;
            this.fullLabel.Text = "Your Full Name:";
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.Location = new System.Drawing.Point(107, 95);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(10, 13);
            this.outputLabel.TabIndex = 3;
            this.outputLabel.Text = ".";
            // 
            // firstTextBox
            // 
            this.firstTextBox.Location = new System.Drawing.Point(108, 43);
            this.firstTextBox.Name = "firstTextBox";
            this.firstTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstTextBox.TabIndex = 4;
            // 
            // lastTextBox
            // 
            this.lastTextBox.Location = new System.Drawing.Point(108, 70);
            this.lastTextBox.Name = "lastTextBox";
            this.lastTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastTextBox.TabIndex = 5;
            // 
            // nameButton
            // 
            this.nameButton.Location = new System.Drawing.Point(16, 127);
            this.nameButton.Name = "nameButton";
            this.nameButton.Size = new System.Drawing.Size(139, 30);
            this.nameButton.TabIndex = 6;
            this.nameButton.Text = "Show &Name";
            this.nameButton.UseVisualStyleBackColor = true;
            this.nameButton.Click += new System.EventHandler(this.nameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(162, 127);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(122, 30);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // GoodmanStringDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 169);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.nameButton);
            this.Controls.Add(this.lastTextBox);
            this.Controls.Add(this.firstTextBox);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.fullLabel);
            this.Controls.Add(this.lastLabel);
            this.Controls.Add(this.firstLabel);
            this.Name = "GoodmanStringDemo";
            this.Text = "String Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstLabel;
        private System.Windows.Forms.Label lastLabel;
        private System.Windows.Forms.Label fullLabel;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.TextBox firstTextBox;
        private System.Windows.Forms.TextBox lastTextBox;
        private System.Windows.Forms.Button nameButton;
        private System.Windows.Forms.Button exitButton;
    }
}


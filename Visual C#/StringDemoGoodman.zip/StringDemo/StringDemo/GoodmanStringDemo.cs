﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StringDemo
{
    public partial class GoodmanStringDemo : Form
    {
        public GoodmanStringDemo()
        {
            InitializeComponent();
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void nameButton_Click(object sender, EventArgs e)
        {
            char firstInitial = firstTextBox.Text[0];
            char lastInitial = lastTextBox.Text[0];
            string fullName;

            fullName = firstInitial.ToString().ToUpper() + firstTextBox.Text.ToLower().Substring(1) + " " + lastInitial.ToString().ToUpper() + lastTextBox.Text.ToLower().Substring(1);

            outputLabel.Text = fullName;
        }
    }
}

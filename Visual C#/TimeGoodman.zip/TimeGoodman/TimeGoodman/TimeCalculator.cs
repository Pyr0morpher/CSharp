﻿/** =========================================================

 Corbin Goodman
 Windows 10
 Microsoft Visual Studio 2017
 CIS 169 C# 
 Module 4 Time
 Transfers Seconds into minutes, hours, and days.
 Academic Honesty:
 I attest that this is my original work.
 I have not used unauthorized source code, either modified or unmodified.
 I have not given other fellow student(s) access to my program.

=========================================================== **/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeGoodman
{
    public partial class TimeCalculator : Form
    {
        int seconds = 0;
        int minutes = 0;
        int hours = 0;
        int days = 0;

        public TimeCalculator()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            int totalSec; // total seconds


            if (int.TryParse(secTextBox.Text, out totalSec)) {

                seconds = totalSec;


                if (seconds >= 60) {

                    minutes = seconds/60;
                    seconds = seconds - (60 * minutes) ;
                }
                if (minutes >= 60) {

                    hours = minutes/60;
                    minutes = minutes - (60 * hours);
                }
                if (hours >= 24)
                {

                    days = hours / 24;
                    hours = hours - (24 * days);
                }
                /*
                else {
                    secOut.Text = "ERROR";
                    minOut.Visible = false;
                    HourOut.Visible = false;
                    daysOut.Visible = false;

                }
                */
                secOut.Text = seconds.ToString();
                minOut.Text = minutes.ToString();
                HourOut.Text = hours.ToString();
                daysOut.Text = days.ToString();
              

            }
        }

        private void extButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clrButton_Click(object sender, EventArgs e)
        {
            secOut.Text = "0";
            minOut.Text = "0";
            HourOut.Text = "0";
            daysOut.Text = "0";
        }
    }
    }

﻿namespace TimeGoodman
{
    partial class TimeCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TimeCalculator));
            this.timeGroupBox = new System.Windows.Forms.GroupBox();
            this.secOut = new System.Windows.Forms.Label();
            this.minOut = new System.Windows.Forms.Label();
            this.HourOut = new System.Windows.Forms.Label();
            this.daysOut = new System.Windows.Forms.Label();
            this.secondsLabel = new System.Windows.Forms.Label();
            this.minLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.daysLabel = new System.Windows.Forms.Label();
            this.enterSeconds = new System.Windows.Forms.Label();
            this.secTextBox = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.clrButton = new System.Windows.Forms.Button();
            this.extButton = new System.Windows.Forms.Button();
            this.timeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // timeGroupBox
            // 
            this.timeGroupBox.Controls.Add(this.secOut);
            this.timeGroupBox.Controls.Add(this.minOut);
            this.timeGroupBox.Controls.Add(this.HourOut);
            this.timeGroupBox.Controls.Add(this.daysOut);
            this.timeGroupBox.Controls.Add(this.secondsLabel);
            this.timeGroupBox.Controls.Add(this.minLabel);
            this.timeGroupBox.Controls.Add(this.hoursLabel);
            this.timeGroupBox.Controls.Add(this.daysLabel);
            this.timeGroupBox.Location = new System.Drawing.Point(13, 62);
            this.timeGroupBox.Name = "timeGroupBox";
            this.timeGroupBox.Size = new System.Drawing.Size(237, 208);
            this.timeGroupBox.TabIndex = 0;
            this.timeGroupBox.TabStop = false;
            this.timeGroupBox.Text = "Results";
            // 
            // secOut
            // 
            this.secOut.AutoSize = true;
            this.secOut.Location = new System.Drawing.Point(165, 159);
            this.secOut.Name = "secOut";
            this.secOut.Size = new System.Drawing.Size(13, 13);
            this.secOut.TabIndex = 7;
            this.secOut.Text = "0";
            // 
            // minOut
            // 
            this.minOut.AutoSize = true;
            this.minOut.Location = new System.Drawing.Point(165, 120);
            this.minOut.Name = "minOut";
            this.minOut.Size = new System.Drawing.Size(13, 13);
            this.minOut.TabIndex = 6;
            this.minOut.Text = "0";
            // 
            // HourOut
            // 
            this.HourOut.AutoSize = true;
            this.HourOut.Location = new System.Drawing.Point(165, 88);
            this.HourOut.Name = "HourOut";
            this.HourOut.Size = new System.Drawing.Size(13, 13);
            this.HourOut.TabIndex = 5;
            this.HourOut.Text = "0";
            // 
            // daysOut
            // 
            this.daysOut.AutoSize = true;
            this.daysOut.Location = new System.Drawing.Point(165, 52);
            this.daysOut.Name = "daysOut";
            this.daysOut.Size = new System.Drawing.Size(13, 13);
            this.daysOut.TabIndex = 4;
            this.daysOut.Text = "0";
            // 
            // secondsLabel
            // 
            this.secondsLabel.AutoSize = true;
            this.secondsLabel.Location = new System.Drawing.Point(6, 159);
            this.secondsLabel.Name = "secondsLabel";
            this.secondsLabel.Size = new System.Drawing.Size(52, 13);
            this.secondsLabel.TabIndex = 3;
            this.secondsLabel.Text = "Seconds:";
            // 
            // minLabel
            // 
            this.minLabel.AutoSize = true;
            this.minLabel.Location = new System.Drawing.Point(6, 120);
            this.minLabel.Name = "minLabel";
            this.minLabel.Size = new System.Drawing.Size(47, 13);
            this.minLabel.TabIndex = 2;
            this.minLabel.Text = "Minutes:";
            // 
            // hoursLabel
            // 
            this.hoursLabel.AutoSize = true;
            this.hoursLabel.Location = new System.Drawing.Point(6, 88);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(38, 13);
            this.hoursLabel.TabIndex = 1;
            this.hoursLabel.Text = "Hours:";
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(6, 52);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(34, 13);
            this.daysLabel.TabIndex = 0;
            this.daysLabel.Text = "Days:";
            // 
            // enterSeconds
            // 
            this.enterSeconds.AutoSize = true;
            this.enterSeconds.Location = new System.Drawing.Point(10, 20);
            this.enterSeconds.Name = "enterSeconds";
            this.enterSeconds.Size = new System.Drawing.Size(80, 13);
            this.enterSeconds.TabIndex = 1;
            this.enterSeconds.Text = "Enter Seconds:";
            // 
            // secTextBox
            // 
            this.secTextBox.Location = new System.Drawing.Point(96, 20);
            this.secTextBox.Name = "secTextBox";
            this.secTextBox.Size = new System.Drawing.Size(145, 20);
            this.secTextBox.TabIndex = 2;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(13, 287);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 3;
            this.calcButton.Text = "&Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // clrButton
            // 
            this.clrButton.Location = new System.Drawing.Point(95, 287);
            this.clrButton.Name = "clrButton";
            this.clrButton.Size = new System.Drawing.Size(75, 23);
            this.clrButton.TabIndex = 4;
            this.clrButton.Text = "C&lear";
            this.clrButton.UseVisualStyleBackColor = true;
            this.clrButton.Click += new System.EventHandler(this.clrButton_Click);
            // 
            // extButton
            // 
            this.extButton.Location = new System.Drawing.Point(175, 287);
            this.extButton.Name = "extButton";
            this.extButton.Size = new System.Drawing.Size(75, 23);
            this.extButton.TabIndex = 5;
            this.extButton.Text = "E&xit";
            this.extButton.UseVisualStyleBackColor = true;
            this.extButton.Click += new System.EventHandler(this.extButton_Click);
            // 
            // TimeCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(260, 327);
            this.Controls.Add(this.extButton);
            this.Controls.Add(this.clrButton);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.secTextBox);
            this.Controls.Add(this.enterSeconds);
            this.Controls.Add(this.timeGroupBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TimeCalculator";
            this.Text = "Time Calculator";
            this.timeGroupBox.ResumeLayout(false);
            this.timeGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox timeGroupBox;
        private System.Windows.Forms.Label secOut;
        private System.Windows.Forms.Label minOut;
        private System.Windows.Forms.Label HourOut;
        private System.Windows.Forms.Label daysOut;
        private System.Windows.Forms.Label secondsLabel;
        private System.Windows.Forms.Label minLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.Label enterSeconds;
        private System.Windows.Forms.TextBox secTextBox;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Button clrButton;
        private System.Windows.Forms.Button extButton;
    }
}

